chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "playAudio" && message.audioData) {
      const audio = new Audio(message.audioData);
      audio.play().then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        console.error("Audio playback error:", err);
        sendResponse({ success: false, error: err });
      });
      return true; // Keeps the message channel open for sendResponse
    }
  });
  