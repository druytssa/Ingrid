// Create the context menu on extension install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "speakWithJuniper",
    title: "Juniper",
    contexts: ["selection"]
  });
});

// Handle messages from popup.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "play-stored-audio") {
    console.log("[background] Received 'play-stored-audio' request from popup");
    playStoredAudio();
  }
});

// Plays last stored audio (used by popup or context menu)
function playStoredAudio() {
  chrome.storage.local.get(['lastAudioData'], (result) => {
    if (chrome.runtime.lastError) {
      console.error("[background] Storage error while playing:", chrome.runtime.lastError);
      return;
    }

    if (result.lastAudioData) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://")) {
          console.warn("[background] Playback blocked: restricted page like chrome:// or extension page.");
          return;
        }

        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (audioUrl) => {
            const audio = new Audio(audioUrl);
            audio.volume = 1;
            audio.play().then(() => {
              console.log("✅ Streaming audio playing");
            }).catch((err) => {
              console.error("🚫 Streaming audio failed:", err);
            });
          },
          args: [result.lastAudioData]
        });
      });
    } else {
      console.warn("[background] No audio data found to play.");
    }
  });
}

// Fetches TTS audio from OpenAI and plays it directly via injected script
function fetchVoiceAndPlay(text) {
  console.log("fetchVoiceAndPlay called with text:", text);
  const startTime = performance.now();

  fetch('https://api.openai.com/v1/audio/speech', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer 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',
      'Accept': 'audio/mpeg'
    },
    body: JSON.stringify({
      model: "tts-1-1106",
      input: text,
      voice: "sage",
      response_format: "mp3"
    })
  })
    .then(response => {
      console.log(`[TIME] TTS API response received in ${(performance.now() - startTime).toFixed(1)}ms`);
      if (!response.ok) {
        return response.text().then(errText => {
          console.error("Error response body:", errText);
          throw new Error(`API error: ${response.status} ${response.statusText}`);
        });
      }
      return response.blob();
    })
    .then(blob => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const arrayBuffer = reader.result;
        const uint8Array = Array.from(new Uint8Array(arrayBuffer));

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tab = tabs[0];
          if (!tab || !tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://")) {
            console.warn("[background] Playback blocked: restricted page like chrome:// or extension page.");
            return;
          }

          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (audioBytes) => {
              const blob = new Blob([new Uint8Array(audioBytes)], { type: "audio/mpeg" });
              const audioUrl = URL.createObjectURL(blob);
              const audio = new Audio(audioUrl);
              audio.volume = 1;
              audio.play().then(() => {
                console.log("🎤 Juniper is speaking!");
              }).catch((err) => {
                console.error("🚫 Audio playback failed:", err);
              });
            },
            args: [uint8Array]
          });

          chrome.runtime.sendMessage({ type: "audio-ready" }, () => {
            if (chrome.runtime.lastError) {
              console.warn("[background] Popup not open to receive 'audio-ready' — no biggie.");
            } else {
              console.log("✅ Sent 'audio-ready' message to popup.");
            }
          });
        });
      };

      reader.readAsArrayBuffer(blob);
    })
    .catch(error => {
      console.error("Error in TTS API:", error);
    });
}

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "speakWithJuniper" && info.selectionText) {
    fetchVoiceAndPlay(info.selectionText);
  }
});
