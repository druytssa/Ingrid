let state = { currentIdx: null, audio: null, blobs: new Map(), bookmarks: new Map() };

chrome.runtime.onMessage.addListener(async (msg, sender) => {
  if (msg.type === 'CH_PLAY') { await playChapter(msg.idx, msg.text, sender.tab.id); }
  if (msg.type === 'CH_PAUSE') { pauseChapter(sender.tab.id); }
  if (msg.type === 'CH_REPLAY') { replaySeconds(msg.seconds ?? 10, sender.tab.id); }
  if (msg.type === 'CH_BOOKMARK') { bookmarkHere(sender.tab.id); }
});

async function playChapter(idx, text, tabId) {
  if (state.currentIdx !== idx) { await loadAudio(idx, text); }
  if (!state.audio) return;
  state.currentIdx = idx;
  await state.audio.play().catch(() => {});
  notify(tabId, 'playing');
  state.audio.onended = () => {
    notify(tabId, 'stopped');
  };
}

function pauseChapter(tabId) {
  if (state.audio && !state.audio.paused) state.audio.pause();
  notify(tabId, 'paused');
}

function replaySeconds(s, tabId) {
  if (!state.audio) return;
  state.audio.currentTime = Math.max(0, state.audio.currentTime - s);
  notify(tabId, 'playing');
}

function bookmarkHere(tabId) {
  if (!state.audio || state.currentIdx == null) return;
  state.bookmarks.set(state.currentIdx, state.audio.currentTime);
  chrome.storage.local.set({ aiTtsBookmarks: [...state.bookmarks.entries()] });
  notify(tabId, 'playing');
}

async function loadAudio(idx, text) {
  if (state.blobs.has(idx)) { return attachAudio(state.blobs.get(idx)); }
  const blob = await openAiTtsToBlob(text);
  state.blobs.set(idx, blob);
  attachAudio(blob);
}

function attachAudio(blob) {
  if (state.audio) { state.audio.pause(); state.audio.src = ''; state.audio.remove(); }
  const url = URL.createObjectURL(blob);
  const audio = new Audio(url);
  audio.preload = 'auto';
  state.audio = audio;
}

function notify(tabId, stateStr) {
  chrome.tabs.sendMessage(tabId, { type: 'CH_ACTIVE', idx: state.currentIdx, state: stateStr });
}

async function openAiTtsToBlob(text) {
  const resp = await fetch('https://api.openai.com/v1/audio/speech', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${await getApiKey()}`
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini-tts',
      voice: 'alloy',
      input: text,
      format: 'mp3'
    })
  });
  const arrayBuf = await resp.arrayBuffer();
  return new Blob([arrayBuf], { type: 'audio/mpeg' });
}

async function getApiKey() {
  const { openai_api_key } = await chrome.storage.sync.get('openai_api_key');
  return openai_api_key;
}
